package com.cg.user.dao;

import java.sql.*;

import com.cg.user.dto.Login;
import com.cg.user.exception.LoginException;
import com.cg.user.util.DBUtil;

public class LoginDaoImpl 
implements LoginDao
{
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	

	@Override
	public Login getUserByUnm(String unm) 
			throws LoginException{
		Login user = null;
		try
		{
		con = DBUtil.getCon();
		System.out.println("Got Connection : ");
		String qry = "SELECT * FROM user_142875 WHERE user_id = ?";
		pst = con.prepareStatement(qry);
		pst.setString(1, unm);
		rs = pst.executeQuery();
		rs.next();
		user = new Login(rs.getString("user_id"),rs.getString("password"));
		}
		catch(SQLException se)
		{
			throw new LoginException(se.getMessage());
		}
		return user;
	}

}
