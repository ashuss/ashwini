package com.capgemini.contact.service;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.uas.exception.ApplicantException;

public interface ApplyService
{
	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long appId) throws ApplicantException;
	public boolean isValidApplicant(ApplicantBean applicant) throws ApplicantException;
	
	public boolean validateContactNo(long contactNo);
	public boolean validateFirstName(String fName);
	public boolean validateLastName(String lName);
	public boolean validateEmail(String email);
	public boolean validateAggregate(float aggregate);
	public boolean validateStream(String stream);
}
