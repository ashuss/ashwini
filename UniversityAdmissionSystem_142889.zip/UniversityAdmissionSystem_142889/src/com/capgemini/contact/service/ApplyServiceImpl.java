package com.capgemini.contact.service;

import java.util.regex.Pattern;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.uas.exception.ApplicantException;

public class ApplyServiceImpl implements ApplyService
{
	ApplyDao applyDao = null;
	
	public ApplyServiceImpl()
	{
		applyDao = new ApplyDaoImpl();
	}

	@Override
	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException
	{
		return applyDao.addApplicantDetails(applicant);
	}

	@Override
	public ApplicantBean getApplicantDetails(long appId) throws ApplicantException
	{
		return applyDao.getApplicantDetails(appId);
	}

	@Override
	public boolean isValidApplicant(ApplicantBean applicant) throws ApplicantException
	{
		String fName = applicant.getfName();
		String lName = applicant.getlName();
		String email = applicant.getEmail();
		String stream = applicant.getStream();
		
		long contact = applicant.getContactNo();
		float aggr = applicant.getAggregate();
		
		if(validateContactNo(contact) && validateFirstName(fName) && validateLastName(lName) && validateEmail(email) && validateStream(stream) && validateAggregate(aggr))
		{
			return true;
		}
		else if(!validateFirstName(fName))
		{
			throw new ApplicantException("Only alphaets are allowed & First letter should be capital. "
					+ "Please do the required change in First Name.");
		}
		else if(!validateLastName(lName))
		{
			throw new ApplicantException("Only alphaets are allowed & First letter should be capital. "
					+ "Please do the required change in First Name.");
		}
		else if(!validateEmail(email))
		{
			throw new ApplicantException("Please enter a valid email ID.");
		}
		else if(!validateStream(stream))
		{
			throw new ApplicantException("Please enter 1 among these streams:\nComputerSc.\nInformationTech.");
		}
		else if(!validateAggregate(aggr))
		{
			throw new ApplicantException("Aggregate should not be negative.");
		}
		else
		{
			throw new ApplicantException("Contact no should start with 7/8/9 and should be 10 digits only.");
		}
	}

	@Override
	public boolean validateContactNo(long contactNo)
	{
		//Mobile No/ Contact No starting digit should be (7/8/9)
		//And it should be 10 digit only
		if((contactNo > 6999999999l) && (contactNo < 10000000000l))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public boolean validateFirstName(String fName)
	{
		String namePattern = "[A-Z][a-z]{1,20}";
		
		if(Pattern.matches(namePattern, fName))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean validateLastName(String lName)
	{
		String namePattern = "[A-Z][a-z]{1,20}";
		
		if(Pattern.matches(namePattern, lName))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean validateEmail(String email)
	{
		String emailID = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		
		if(Pattern.matches(emailID ,email))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean validateAggregate(float aggregate)
	{
		if(aggregate > 0.0f)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean validateStream(String stream)
	{
		String stream1 = "ComputerSc.";
		String stream2 = "InformationTech.";
		
		if(Pattern.matches(stream1, stream) || Pattern.matches(stream2, stream))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
