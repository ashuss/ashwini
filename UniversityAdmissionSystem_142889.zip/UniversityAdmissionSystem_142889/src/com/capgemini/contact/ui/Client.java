package com.capgemini.contact.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.service.ApplyService;
import com.capgemini.contact.service.ApplyServiceImpl;
import com.capgemini.uas.exception.ApplicantException;

public class Client
{
	static Scanner sc = null;
	static ApplyService applSer = null;
	
	public static void main(String[] args)
	{
		sc = new Scanner(System.in);
		int choice = 0;
		applSer = new ApplyServiceImpl();
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		while(true)
		{
			System.out.println("What would you like to do?");
			System.out.println("1:Enter Applicant Details\n"
					+ "2.View Applicant Details Based on Applicant Id\n"
					+ "0.Exit\n");
			
			choice = sc.nextInt();
			
			switch(choice)
			{
			case 1:
				insertDetails();
				break;
			case 2:
				viewDetails();
				break;
			default:
				System.out.println("Thank you for applying !!");
				System.exit(0);
			}
		}
	}
/*************************Main Ends Here****************************/
	
	public static void insertDetails()
	{
		String fName,lName,email,stream;
		long phn;
		float aggr;
		
		System.out.println("Enter First Name : ");
		fName = sc.next();
		System.out.println("Enter Last Name : ");
		lName = sc.next();
		System.out.println("Enter Contact No : ");
		phn = sc.nextLong();
		System.out.println("Enter email : ");
		email = sc.next();
		System.out.println("Enter Stream : "	//User will enter stream without spaces
				+ "\nComputerSc.\nInformationTech.");
		stream = sc.next();
		System.out.println("Enter Aggregate : ");
		aggr = sc.nextFloat();
		
		ApplicantBean ab = new ApplicantBean();
		ab.setAggregate(aggr);
		ab.setContactNo(phn);
		ab.setEmail(email);
		ab.setfName(fName);
		ab.setlName(lName);
		ab.setStream(stream);
		
		int dataAdded;
		try
		{
			if(applSer.isValidApplicant(ab))
			{
				dataAdded = applSer.addApplicantDetails(ab);
				//System.out.println("Data added: "+dataAdded);
			}
		}
		catch (ApplicantException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
	}
/***************insertDetails() Ends Here***************************/
	
	public static void viewDetails()
	{
		System.out.println("Enter the Applicant ID : ");
		long id = sc.nextLong();
		
		try
		{
			ApplicantBean ab = applSer.getApplicantDetails(id);
			
			System.out.println(ab);
		}
		catch (ApplicantException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
	}
}
