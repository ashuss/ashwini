package com.capgemini.apply.dao;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.uas.exception.ApplicantException;

public interface ApplyDao
{
	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long appId) throws ApplicantException;
	public long generateApplicantId() throws ApplicantException;
}
