package com.capgemini.apply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.uas.exception.ApplicantException;
import com.cg.uas.util.DBUtil;

public class ApplyDaoImpl implements ApplyDao
{
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	int dataAdded;
	
	@Override
	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException
	{
		String insertQry = "INSERT INTO Candidate_Detail "
				+ "(applyId,firstName,lastName,contactNo,email,aggregate,stream) "
				+ "VALUES (?,?,?,?,?,?,?)";
		
		try
		{
			con = DBUtil.getCon();
			
			pst = con.prepareStatement(insertQry);
			long generatedValue = generateApplicantId();
			pst.setLong(1, generatedValue);
			pst.setString(2, applicant.getfName());
			pst.setString(3, applicant.getlName());
			pst.setLong(4, applicant.getContactNo());	
			pst.setString(5, applicant.getEmail());
			pst.setFloat(6, applicant.getAggregate());
			pst.setString(7, applicant.getStream());
			dataAdded = pst.executeUpdate();
			
			System.out.println("Thank you "+applicant.getfName()+" "+applicant.getlName()+
					" your Unique Id is "+generatedValue+ 
					" we will contact you shortly.");
		}
		catch (Exception e)
		{
			throw new ApplicantException(e.getMessage());
			//e.printStackTrace();
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (SQLException e)
			{
				throw new ApplicantException(e.getMessage());
			}
		}
		
		return dataAdded;
	}

	@Override
	public ApplicantBean getApplicantDetails(long appId) throws ApplicantException
	{
		String selectQry = "SELECT * FROM Candidate_Detail WHERE applyId = (?)";
		
		ApplicantBean appl = null;
		
		try
		{
			con = DBUtil.getCon();
			pst = con.prepareStatement(selectQry);
			pst.setLong(1, appId);
			
			rs = pst.executeQuery();
			rs.next();
			appl = new ApplicantBean(rs.getLong("applyId"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("email"),
					rs.getLong("contactNo"), rs.getString("stream"), rs.getFloat("aggregate"));
		}
		catch (Exception e)
		{
			throw new ApplicantException("Sorry no details found!!");
			//e.printStackTrace();
		}
		
		
		
		return appl;
	}
	
	public long generateApplicantId() throws ApplicantException
	{
		String qry = "SELECT apply_id_seq.NEXTVAL FROM DUAL";
		long generatedValue;
		
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(qry);
			
			rs.next();
			generatedValue = rs.getLong(1);
			
		}
		catch (Exception e)
		{
			throw new ApplicantException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (SQLException e)
			{
				throw new ApplicantException(e.getMessage());
			}
		}
		
		return generatedValue;
	}
}
