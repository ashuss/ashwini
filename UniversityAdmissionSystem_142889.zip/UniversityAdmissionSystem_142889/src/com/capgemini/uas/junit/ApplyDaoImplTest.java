package com.capgemini.uas.junit;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.uas.exception.ApplicantException;

public class ApplyDaoImplTest
{
	static ApplyDao appDao = null;
	static ApplicantBean ab1 = null;
	static ApplicantBean ab2 = null;
	
	@BeforeClass
	public static void beforeClass() throws ApplicantException
	{
		appDao = new ApplyDaoImpl();
		ab1 = new ApplicantBean(appDao.generateApplicantId() , "Abc" , "Xyz" , "abc@xyz.com" , 985612307l , "ComputerSc." , 78.5f);
		ab2 = new ApplicantBean(appDao.generateApplicantId() , "Pqrs" , "Wxyz" , "pqrs@lmn.com" , 9852812307l , "InformationTech." , 78.5f);
	}
	
	@Test
	public void testAddApplDetails1() throws ApplicantException
	{
		Assert.assertEquals(1, appDao.addApplicantDetails(ab1));
	}
	
	@Test
	public void testAddApplDetails2() throws ApplicantException
	{
		Assert.assertEquals(1, appDao.addApplicantDetails(ab2));
	}
	
	@Test
	public void testGetApplDetails1() throws ApplicantException
	{
		Assert.assertNotNull(appDao.getApplicantDetails(1007));
	}
	
	@Test(expected = Exception.class)
	public void testGetApplDetails2() throws ApplicantException
	{
		Assert.assertNotNull(appDao.getApplicantDetails(5014));
	}
}
