package com.cg.otba.dao;

import java.util.List;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;
import com.cg.otba.exception.ShowException;

public interface ShowDao
{
	List<Show> getShowDetails() throws ShowException;
	
	int updateShowDetails(Show s, Customer c) throws ShowException;
	
	Show getShow(String bid) throws ShowException;
}
