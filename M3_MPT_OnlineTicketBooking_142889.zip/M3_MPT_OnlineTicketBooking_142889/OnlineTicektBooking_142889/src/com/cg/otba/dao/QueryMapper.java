package com.cg.otba.dao;

public interface QueryMapper
{
	String SELECT_ALL_SHOWDETAILS = "SELECT * FROM ShowDetails";
	
	String UPDATE_SHOW = "UPDATE ShowDetails SET AvSeats = AvSeats-? WHERE ShowId = ?";
	
	String SELECT_SHOW = "SELECT * FROM ShowDetails WHERE ShowId=?";
}
