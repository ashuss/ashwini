package com.cg.otba.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;
import com.cg.otba.exception.ShowException;
import com.cg.otba.util.DBUtil;

public class ShowDaoImpl implements ShowDao
{
	Connection con;
	
	@Override
	public List<Show> getShowDetails() throws ShowException
	{
		List<Show> slist = new ArrayList<>();
		Statement st;
		
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			ResultSet rs = st.executeQuery(QueryMapper.SELECT_ALL_SHOWDETAILS);
			
			while(rs.next())
			{
				Show s = new Show();
				s.setShowId(rs.getString("ShowId"));
				s.setShowName(rs.getString("ShowName"));
				s.setLoc(rs.getString("Location"));
				
				Date date = rs.getDate("ShowDate");
				String dt = date.toString();
				DateTimeFormatter format= DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate sdt = LocalDate.parse(dt, format);
				s.setShowDate(sdt);
				
				s.setAvSeats(rs.getInt("AvSeats"));
				s.setPrice(rs.getFloat("PriceTicket"));
				
				slist.add(s);
			}
		}
		catch (SQLException e)
		{
			throw new ShowException("Problem in fetching Show list: "+e.getMessage());
		}
		return slist;
	}

	@Override
	public int updateShowDetails(Show s, Customer c) throws ShowException
	{
		int dataUpdated = 0;
				
		con = DBUtil.getCon();
		try
		{
			PreparedStatement pst = con.prepareStatement(QueryMapper.UPDATE_SHOW);
			int seats = c.getNoS();	//gets no of seats booked by the customer
			String id = s.getShowId();	//gets Show ID of show
			
			pst.setInt(1, seats);
			pst.setString(2, id);
			
			dataUpdated = pst.executeUpdate();
			
		}
		catch (SQLException e)
		{
			throw new ShowException("Problem in updating show details: "+e.getMessage());
		}
		
		return dataUpdated;
	}

	@Override
	public Show getShow(String bid) throws ShowException
	{
		con = DBUtil.getCon();
		Show s = null;
		
		try
		{
			PreparedStatement pst = con.prepareStatement(QueryMapper.SELECT_SHOW);
			pst.setString(1, bid);
			ResultSet rs = pst.executeQuery();
			
			if(rs.next())
			{
				s = new Show();
				s.setShowName(rs.getString("ShowName"));
				s.setPrice(rs.getFloat("PriceTicket"));
				s.setAvSeats(rs.getInt("AvSeats"));
				s.setLoc(rs.getString("Location"));
				s.setShowId(rs.getString("ShowId"));
				s.setPrice(rs.getFloat("PriceTicket"));
			}
			else
			{
				throw new ShowException("Show not found");
			}
		}
		catch (SQLException e)
		{
			throw new ShowException("Problem in fetching Show details: "+e.getMessage());
		}
		return s;
	}

}
