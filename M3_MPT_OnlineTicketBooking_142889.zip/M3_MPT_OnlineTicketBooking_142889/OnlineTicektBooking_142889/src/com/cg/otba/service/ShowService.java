package com.cg.otba.service;

import java.util.List;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;
import com.cg.otba.exception.ShowException;

public interface ShowService
{
	List<Show> getShowDetails() throws ShowException;
	
	int updateShowDetails(Show s, Customer c) throws ShowException;
	
	Show getShow(String bid) throws ShowException;
}
