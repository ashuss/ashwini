package com.cg.otba.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.otba.exception.ShowException;

public class DBUtil
{
	public static Connection getCon() throws ShowException
	{
		Connection con = null;
		//con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		
		try
		{
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource)context.lookup("java:/JDBC/OracleDS");
			con = ds.getConnection();
		}
		catch (NamingException e)
		{
			throw new ShowException("Problem in obtaining Datasource: "+e.getMessage());
		}
		catch(SQLException e)
		{
			throw new ShowException("Problem in obtaining Connection: "+e.getMessage());
		}
		
		return con;
	}
}
