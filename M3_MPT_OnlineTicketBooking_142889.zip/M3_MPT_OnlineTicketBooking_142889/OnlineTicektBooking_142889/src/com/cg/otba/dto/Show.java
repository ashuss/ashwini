package com.cg.otba.dto;

import java.time.LocalDate;

public class Show
{
	private String showId;
	private String showName;
	private String loc;
	private LocalDate showDate;
	private int avSeats;
	private float price;
	public Show() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Show(String showId, String showName, String loc, LocalDate showDate,
			int avSeats, float price) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.loc = loc;
		this.showDate = showDate;
		this.avSeats = avSeats;
		this.price = price;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public LocalDate getShowDate() {
		return showDate;
	}
	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return avSeats;
	}
	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
}
