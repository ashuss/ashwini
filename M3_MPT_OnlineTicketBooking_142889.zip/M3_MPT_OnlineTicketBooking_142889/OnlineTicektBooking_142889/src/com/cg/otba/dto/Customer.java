package com.cg.otba.dto;

public class Customer
{
	private String name;
	private String mno;
	private float total;
	private int noS;
	
	public int getNoS() {
		return noS;
	}
	public void setNoS(int noS) {
		this.noS = noS;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMno() {
		return mno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String mno, float total, int noS) {
		super();
		this.name = name;
		this.mno = mno;
		this.total = total;
		this.noS = noS;
	}
	
}
