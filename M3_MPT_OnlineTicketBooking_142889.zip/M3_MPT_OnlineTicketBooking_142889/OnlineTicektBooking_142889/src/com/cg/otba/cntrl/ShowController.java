package com.cg.otba.cntrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otba.dto.Customer;
import com.cg.otba.dto.Show;
import com.cg.otba.exception.ShowException;
import com.cg.otba.service.ShowService;
import com.cg.otba.service.ShowServiceImpl;

@WebServlet(urlPatterns={"/home","/booknow","/book"})
public class ShowController extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    public ShowController()
    {
        super();
    }

	public void init(ServletConfig config) throws ServletException
	{}

	public void destroy()
	{}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String url = request.getServletPath();
		String targetUrl = "";
		ShowService sSer = new ShowServiceImpl();
		
		switch(url)
		{
		case "/home":
			try
			{
				List<Show> slist = sSer.getShowDetails();
				request.setAttribute("slist", slist);
				targetUrl = "Home.jsp";
			}
			catch (ShowException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			break;
			
		case "/booknow":
			String bid = request.getParameter("bid").toString();
			
			try
			{
				Show s = sSer.getShow(bid);
				HttpSession sess = request.getSession();
				sess.setAttribute("s", s);
				targetUrl = "BookNow.jsp";
			}
			catch (ShowException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			break;
			
		case "/book":
			HttpSession sess = request.getSession(false);
			Show s = (Show)sess.getAttribute("s");
			Customer c = new Customer();
			c.setName(request.getParameter("cnm"));
			c.setMno(request.getParameter("mno"));
			
			int noSeats = Integer.parseInt(request.getParameter("seats"));
			float tp = s.getPrice();
			tp = tp * noSeats;
			c.setTotal(tp);
			c.setNoS(noSeats);
			
			try
			{
				int dataUpdated = sSer.updateShowDetails(s, c);
				System.out.println("Data Update:" +dataUpdated);
			}
			catch (ShowException e)
			{
				request.setAttribute("error", e.getMessage());
				targetUrl = "Error.jsp";
			}
			
			request.setAttribute("c", c);
			targetUrl = "Success.jsp";
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
