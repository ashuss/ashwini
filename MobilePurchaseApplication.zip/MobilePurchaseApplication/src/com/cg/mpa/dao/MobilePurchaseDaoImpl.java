package com.cg.mpa.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;






import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.MobileException;
import com.cg.mpa.dto.PurchaseDetails;
import com.cg.mpa.util.DBUtil;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {
Connection conn;
	@Override
	public List<Mobile> getAllMobiles() throws MobileException
	{
		List<Mobile>mlist=new ArrayList<>();
		
		
		try
		{
			conn=DBUtil.getCon();
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			
		while(rst.next())
		{
			Mobile m=new Mobile();
			m.setMobileid(rst.getLong("mobileid"));
			m.setMname(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setPrice(rst.getInt("quantity"));
			
			mlist.add(m);
			
		}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching Mobile List" +e.getMessage());
		}
		
		return mlist;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException 
	{
		Mobile m=null;
		try
		{
			conn=DBUtil.getCon();
			
			PreparedStatement pst=null;
			pst=conn.prepareStatement(QueryMapper.SELECT_MOBILE);
			pst.setLong(1,mid);
			ResultSet rst=pst.executeQuery();
		
			if(rst.next())
			{
			m=new Mobile();
			m.setMobileid(rst.getLong("mobileid"));
			m.setMname(rst.getString("name"));
			m.setPrice(rst.getDouble("price"));
			m.setPrice(rst.getInt("quantity"));
			}
			else
			{
			throw new MobileException("Mobile not found");
			}
		}
		catch(SQLException e)
		{
			throw new MobileException("Problem in fetching Mobile Details: " +e.getMessage());
		}
		return m;
	}
	
	
		private long generatePurchaseId()throws MobileException 
		{
			long pid=0;
			
			try
			{
				conn=DBUtil.getCon();
			
				Statement st=conn.createStatement();
				ResultSet rst=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
				rst.next();
				pid=rst.getLong(1);
				
			}
			catch(SQLException e)
			{
				throw new MobileException("Problem in generating purchase id" +e.getMessage());
			}
			return pid;
		}
		
		
	@Override
	public long insertPurchaseDetails(PurchaseDetails pDetails)
			throws MobileException
	{
		
		try
		{
			conn=DBUtil.getCon();
			
			pDetails.setPurchaseid(generatePurchaseId());
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_QUERY);
			
			pst.setLong(1,pDetails.getPurchaseid());
			pst.setString(2,pDetails.getCname());
			pst.setString(3,pDetails.getMailid());
			pst.setLong(4,pDetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setLong(6,pDetails.getMobileid());
			pst.executeUpdate();
		}
		
		catch(SQLException e)
		{
			
			
			
		}
		return 0;
	}

	public static void main(String[] args) 
	{
	

	}

}
