package com.cg.service;

import java.sql.SQLException;

import com.cg.dto.Register;

public interface RegisterService 
{
	public int insertDetails(Register reg) throws SQLException;
}
